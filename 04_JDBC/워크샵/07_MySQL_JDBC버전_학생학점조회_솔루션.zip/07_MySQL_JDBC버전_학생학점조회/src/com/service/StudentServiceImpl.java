package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dao.StudentDAO;
import com.dto.Student;

public class StudentServiceImpl implements StudentService{

	
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/testdb";
	String userid = "root";
	String passwd = "1234";
	

	public StudentServiceImpl() { // 생성자에 드라이버 로딩
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public List<HashMap<String, String>> gradeSearch(String stuNo){
		List<HashMap<String, String>> list = new ArrayList<>();
		Connection con = null;
		
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			list = dao.gradeSearch(con, stuNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	@Override
	public int capacityChange() {
		int n = 0;
		Connection con = null;
		
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			n = dao.capacityChange(con);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return n; 
	}
	
	@Override
	public int absenceChange(String searchNo) {
		int n = 0;
		Connection con = null;
		
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			n = dao.absenceChange(con, searchNo);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return n; 
	}

	@Override
	public ArrayList<Student> selectBySearchNo(String searchNo) {
		ArrayList<Student> list = new ArrayList<Student>();
		Connection con = null;

		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			list = dao.selectBySearchNo(con, searchNo);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return list;
	}

	@Override
	public ArrayList<Student> selectByEntranceDate(HashMap<Integer, String> map) {
		ArrayList<Student> list = new ArrayList<Student>();
		Connection con = null;

		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			list = dao.selectByEntranceDate(con, map);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public ArrayList<Student> selectByName(String str) {
		ArrayList<Student> list = new ArrayList<Student>();
		Connection con = null;

		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			list = dao.selectByName(con, str);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return list;
	}

	@Override
	public ArrayList<Student> selectAllStudent() {
		ArrayList<Student> list = new ArrayList<Student>();
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			StudentDAO dao = new StudentDAO();
			list = dao.selectAllStudent(con);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

}
