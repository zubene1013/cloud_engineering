package com.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dto.Student;

public interface StudentService {

	public ArrayList<Student> selectAllStudent();
	public ArrayList<Student> selectByName(String str);
	public ArrayList<Student> selectByEntranceDate(HashMap<Integer, String> map);
	public ArrayList<Student> selectBySearchNo(String searchNo);
	public int absenceChange(String searchNo);
	public int capacityChange();
	public List<HashMap<String, String>> gradeSearch(String stuNo);
}
