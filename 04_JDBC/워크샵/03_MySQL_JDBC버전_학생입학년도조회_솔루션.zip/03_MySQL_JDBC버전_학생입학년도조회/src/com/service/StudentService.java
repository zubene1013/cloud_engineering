package com.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.dto.Student;

public interface StudentService {

	public ArrayList<Student> selectAllStudent();
	public ArrayList<Student> selectByName(String str);
	public ArrayList<Student> selectByEntranceDate(HashMap<Integer, String> map);
}
