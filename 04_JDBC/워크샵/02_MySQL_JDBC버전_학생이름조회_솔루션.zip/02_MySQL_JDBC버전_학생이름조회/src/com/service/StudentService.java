package com.service;

import java.util.ArrayList;

import com.dto.Student;

public interface StudentService {

	public ArrayList<Student> selectAllStudent();
	public ArrayList<Student> selectByName(String str);
}
