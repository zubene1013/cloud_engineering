import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import com.dto.Student;
import com.service.StudentServiceImpl;

public class StudentTest {

	public static void main(String[] args) {

		while (true) {
			System.out.println("******************************");
			System.out.println("    [학생 정보 관리 메뉴]      ");
			System.out.println("******************************");
			System.out.println("1. 전체 학생 목록");
			System.out.println("2. 학생 이름 검색");
			System.out.println("3. 학생 입학년도 범위 검색 (예> 2000부터 2003년까지)");
			System.out.println("4. 학생 학번으로 다중 검색 (쉼표 구분자)");
			System.out.println("5. 학생 휴학 일괄 수정");
			System.out.println("0. 종료");
			System.out.println("******************************");
			Scanner scanner = new Scanner(System.in);
			System.out.print("메뉴 입력 => ");
			int n = scanner.nextInt();

			if (n == 1) {
				StudentServiceImpl service = new StudentServiceImpl();
				ArrayList<Student> list = service.selectAllStudent();
				System.out.println("==========================================================");
				System.out.println("학번        이름        주민번호            주소                 입학년도      휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					String stuNo = s.getStuNo();
					String sutName = s.getStuName();
					String stuSsn = s.getStuSsn();
					String stuAddress = s.getStuAdress();
					String entDate = s.getEntDate();
					String absYn = s.getAbsYn();
					System.out.println();
//					System.out.println(s);
					System.out.println( stuNo+ "    " + sutName + "    " + stuSsn + "    "+ stuAddress + "    " +  entDate + "    " + absYn);
				}
				System.out.println("총 학생 수 : " + list.size() + "명");
			} else if (n == 2) {
				System.out.print("검색할 학생명을 입력하시오 => ");
				String str = scanner.next();
				StudentServiceImpl service = new StudentServiceImpl();
				ArrayList<Student> list = service.selectByName(str);
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");

			} else if (n == 3) {
				System.out.print("시작 입학년도를 입력하시오 => ");
				String startYear = scanner.next();
				System.out.print("끝 입학년도를 입력하시오 = > ");
				String endYear = scanner.next();

				StudentServiceImpl service = new StudentServiceImpl();
				HashMap<Integer, String> map = new HashMap<>();
				map.put(0, startYear);
				map.put(1, endYear);
				ArrayList<Student> list = service.selectByEntranceDate(map);
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");
			} else if (n == 4) {
				System.out.print("검색할 학생의 학번을 입력하시오 => ");
				String searchNo = scanner.next(); //A674033,A656014,A612025
				
				StudentServiceImpl service = new StudentServiceImpl();
				ArrayList<Student> list = service.selectBySearchNo(searchNo);
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");

			} else if(n == 5) {
				System.out.print("수정할 학생의 학번을 입력하시오 => ");
				String searchNo = scanner.next();  //9556017,9732111,9747034
				
				StudentServiceImpl service = new StudentServiceImpl();
				int num = service.absenceChange(searchNo);
				System.out.println("총 변경된 학생 수 : " + num + "명");
				
			} else if (n == 0) {
				System.out.println("프로그램이 종료 되었습니다.");
				System.exit(0);
			}
		} // end while
	}// end main
}
