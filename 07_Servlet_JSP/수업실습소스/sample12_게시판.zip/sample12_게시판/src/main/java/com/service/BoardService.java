package com.service;

import java.util.List;

import com.dao.BoardDAO;
import com.dto.BoardDTO;

public interface BoardService {
	  void setDao(BoardDAO dao); // public abstract 가 자동삽입
	  List<BoardDTO> list();     // public abstract 가 자동삽입
}
