package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/MemberServlet2")
public class MemberServlet2 extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			System.out.println("MemberServlet.doPost");
			
			//파라미터 얻기
			String username = request.getParameter("username");
			String age = request.getParameter("age");
			
			System.out.println(username +" " + age);
	
	}

}
