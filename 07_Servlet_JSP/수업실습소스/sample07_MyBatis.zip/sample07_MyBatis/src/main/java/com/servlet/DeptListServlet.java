package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.dao.DeptDAO;
import com.dto.DeptDTO;
import com.service.DeptService;
import com.service.DeptServiceImpl;


@WebServlet("/DeptListServlet")
public class DeptListServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//DeptService 연동
		DeptService service = new DeptServiceImpl();
		service.setDao(new DeptDAO());
		List<DeptDTO> list = service.findAll();
		
		 //응답처리
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 out.print("<html>");
		 out.print("<body>");
		 out.print("<table border='1'>");
		 out.print("<tr>");
		 out.print("<th>부서번호</th>");
		 out.print("<th>부서명</th>");
		 out.print("<th>부서위치</th>");
		 out.print("</tr>");
		 
		 for(DeptDTO dto: list) {
			 out.print("<tr>");
			 out.print("<td>"+dto.getDeptno()+"</td>");
			 out.print("<td>"+dto.getDname()+"</td>");
			 out.print("<td>"+dto.getLoc()+"</td>");
			 out.print("</tr>");
		 
		 }
		 out.print("</table>");
		 out.print("</body>");
		 out.print("</html>");
	}
}
