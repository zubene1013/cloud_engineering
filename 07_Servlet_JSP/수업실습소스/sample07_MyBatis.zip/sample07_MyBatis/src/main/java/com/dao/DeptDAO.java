package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.DeptDTO;

public class DeptDAO {

	//서비스에서 전달해준 SqlSession 이용해서 DB연동
	public List<DeptDTO> findAll(SqlSession session){
		List<DeptDTO> list=null;
		list = session.selectList("com.config.DeptMapper.findAll");
		return list;
	}
}
