<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@page import="com.dto.BoardDTO"%>
<%@page import="java.util.List"%>
  
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>게시판 목록보기</title>
</head>
<body>
<h1>게시판 목록보기</h1>
<table border="1">
  <tr>
    <th>글번호</th>
    <th>제목</th>
    <th>작성자</th>
    <th>작성일</th>
    <th>조회수</th>
  </tr>
<%
    List<BoardDTO> list = (List<BoardDTO>)request.getAttribute("list");
%>  
<%
   for(BoardDTO dto : list){
%>
  <tr>
    <td><%= dto.getNum() %></td>
    <td><a href="BoardRetrieveServlet?num=<%= dto.getNum() %>"><%= dto.getTitle() %></a></td>
    <td><%= dto.getAuthor() %></td>
    <td><%= dto.getWriteday() %></td>
    <td><%= dto.getReadcnt() %></td>
  </tr>
<%
   }//end for
%>  
  
</table>
<a href="BoardWriteUIServlet">글쓰기</a>

</body>
</html>