<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@page import="com.dto.BoardDTO"%>
<%@page import="java.util.List"%>
  
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>게시판 글쓰기화면</title>
</head>
<body>
<h1>게시판 글쓰기화면</h1>
 <form action="BoardWriteServlet" method="get">
   제목:<input type="text" name="title"><br>
   작성자:<input type="text" name="author"><br>
   내용:<textarea name="content" rows="10" cols="10"></textarea><br>
   <input type="submit" value="저장">
 </form>
 <a href="BoardListServlet">목록보기</a>
</body>
</html>