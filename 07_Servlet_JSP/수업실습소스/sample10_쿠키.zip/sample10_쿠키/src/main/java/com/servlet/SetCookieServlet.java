package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/SetCookieServet")
public class SetCookieServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//쿠키 생성
		System.out.println("SetCookieServlet.doGet");
		
		Cookie c = new Cookie("username", "홍길동");
		
		//time-out 지정
		c.setMaxAge(3600); // 1시간
		
		response.addCookie(c);
		
	}
}
