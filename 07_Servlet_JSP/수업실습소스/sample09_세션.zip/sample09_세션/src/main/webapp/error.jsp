<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>로그인 에러</h1>
입력하신 id 및 pw가 틀립니다.
다시 한번 확인하시기 바랍니다.<br>
<a href="loginForm.jsp">로그인화면</a>
</body>
</html>