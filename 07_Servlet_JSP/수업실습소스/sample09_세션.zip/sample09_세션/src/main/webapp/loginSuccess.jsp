<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
    String userid = (String)session.getAttribute("userid");
    String username = (String)session.getAttribute("username");
%>
<h1>로그인 성공</h1>
안녕하세요.<%= userid %>, <%= username %><br>
<a href="MyPageServlet">mypage</a>
</body>
</html>