package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


@WebServlet("/MyPageServlet")
public class MyPageServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {

		// 세션에 저장된 데이터 얻기
		
		// 1. 세션얻기
		HttpSession session = request.getSession();
		
		//2. 데이터 참조
		String userid = (String)session.getAttribute("userid");
		//3. 로그인 여부 체크
		if( userid!=null) {
			
			//request scope에 저장하고 mypage.jsp에서 보여주기
			// userid에 해당하는 값으로 DB연동해서 다음과 같은 데이터를 가져왔다고 가정
			String address="서울";
			String email="xxx@example.com";
			
			request.setAttribute("id", userid);
			request.setAttribute("address", address);
			request.setAttribute("email", email);
			
			//mypage.jsp 요청 위임
			request.getRequestDispatcher("mypage.jsp").forward(request, response);
			
		}else {
			//로그인 안했거나 로그인 했으나 timeout된 경우
			response.sendRedirect("loginForm.jsp");
		}
		
		
	}//end doGet
}//end class
