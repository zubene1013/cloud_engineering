package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dao.BoardDAO;
import com.dto.BoardDTO;

public interface BoardService {
	  void setDao(BoardDAO dao); // public abstract 가 자동삽입
	  List<BoardDTO> list();     // public abstract 가 자동삽입
	  int  write ( BoardDTO dto); // public abstract 가 자동삽입
	  BoardDTO retrieve(int num); // public abstract 가 자동삽입
	  int update( BoardDTO dto);// public abstract 가 자동삽입
	  int delete ( int num); // public abstract 가 자동삽입
}
