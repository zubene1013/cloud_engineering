package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("HelloServlet.doGet");
		 
		 //응답처리
		 response.setContentType("text/html");
		 
		 PrintWriter out = response.getWriter();
		 
		 out.print("<html>");
		 out.print("<body>");
		 out.print("<h1>Hello World</h1>");
		 out.print("<h1>안녕하세요</h1>");
		 out.print("</body>");
		 out.print("</html>");
	
	
	}

}
