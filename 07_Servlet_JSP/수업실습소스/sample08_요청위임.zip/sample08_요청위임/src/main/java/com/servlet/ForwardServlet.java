package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


@WebServlet("/ForwardServlet")
public class ForwardServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("ForwardServlet.doGet");
		
		request.setAttribute("key", "홍길동");
		
		HttpSession session = request.getSession();
		session.setAttribute("key2", "이순신");
		
		ServletContext ctx = getServletContext();
		ctx.setAttribute("key3", "유관순");
				
		//target2.jsp에 요청 위임
		request.getRequestDispatcher("target2.jsp").forward(request, response);
	}
}
