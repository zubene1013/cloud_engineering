<%@ page language="java" 
contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<%@page import="java.util.Date"%>
<%
   ArrayList list = new ArrayList();
   Date d = new Date();
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>01_directive1_page</title>
</head>
<body>

<h1>Hello</h1>
<h1>안녕하세요</h1>
</body>
</html>
