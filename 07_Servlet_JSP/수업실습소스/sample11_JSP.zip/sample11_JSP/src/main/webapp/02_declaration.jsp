<%@ page language="java" 
contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%!
    int num = 10;

    public void hello(){
    	System.out.println("hello");
    }

%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>01_directive2_include</title>
</head>
<body>
<h1>declaration</h1>
</body>
</html>
