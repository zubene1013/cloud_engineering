package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.BoardDAO;
import com.dto.BoardDTO;

public class BoardServiceImpl 
        implements BoardService  {
	
	BoardDAO dao;
	
	@Override
	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}
	@Override
	public List<BoardDTO> list(){
		List<BoardDTO> list = null;
		SqlSession session  = MySqlSessionFactory.getSession();
		try {
			list = dao.list(session);
		}finally {
			session.close();
		}
		return list;
	}
	@Override
	public int write(BoardDTO dto) {
		int n = 0;
		SqlSession session  = MySqlSessionFactory.getSession();
		try {
			n = dao.write(session, dto);
			session.commit();
		}finally {
			session.close();
		}
		return n;
	}
	@Override
	public BoardDTO retrieve(int num) {
		BoardDTO dto = null;
		SqlSession session  = MySqlSessionFactory.getSession();
		try {
			dto = dao.retrieve(session, num);
		}finally {
			session.close();
		}
		return dto;
	}
}
