package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;

public class BoardDAO {

	public List<BoardDTO> list(SqlSession session){
		List<BoardDTO> list = null;
		list = session.selectList("com.config.BoardMapper.list");
		return list;
	}//end list
	
	public int  write (SqlSession session, BoardDTO dto) {
		int n = 0;
		n = session.insert("com.config.BoardMapper.write", dto);
		return n;
	}
	
	public BoardDTO retrieve(SqlSession session, int num){
		BoardDTO dto = null;
			dto = session.selectOne("com.config.BoardMapper.retrieve", num);
		return dto;
	}
}
