package com.controller;

import java.io.IOException;

import com.dto.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class ProductAddServlet
 */
@WebServlet("/ProductDeleteServlet")
public class ProductDeleteServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				String id = request.getParameter("id");
		
	   	        HttpSession session = request.getSession();
	   	        
		        
			    Product p  = (Product)session.getAttribute(id);
		        if(p != null  && id.trim().equals(p.getId())) {
					session.removeAttribute(id);
					response.sendRedirect("productMain.jsp");
		        }else{
		        	response.sendRedirect("error.jsp");
				}  
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
