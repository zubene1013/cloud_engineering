package com.controller;

import java.io.IOException;
import java.util.Calendar;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/reserveTicket")
public class ReserveTicketServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String birthday=request.getParameter("birthday");

		Calendar cal = Calendar.getInstance();

		int type=Integer.parseInt(request.getParameter("type"));
	
		int age=cal.get(Calendar.YEAR) - Integer.parseInt(birthday.substring(0, 4)) ;
		
		int price = 0;
		String [] grades={"미성년자", "성인", "경로우대"};
		int grade=0;
		
		if(age<19){			
			price= (int)(type*0.4);
		}else if(age <60){
			grade=1;
			price=(int)(type*0.1);
		}else{
			grade=2;
			price=(int)(type*0.5);
		}
		
		request.setAttribute("birthday", birthday);
		request.setAttribute("type", type);
		request.setAttribute("age", age);
		request.setAttribute("grade", grades[grade]);
		request.setAttribute("price", price);
		
		RequestDispatcher dis = request.getRequestDispatcher("reservationInfo.jsp");
		dis.forward(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
