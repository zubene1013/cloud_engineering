<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>예약정보</title>
</head>
<body>
<%
     String birthday = (String)request.getAttribute("birthday");
	 int type = (Integer)request.getAttribute("type");
	 int age = (Integer)request.getAttribute("age");
	 String grade = (String)request.getAttribute("grade");
	 int price = (Integer)request.getAttribute("price");

%>
<h3>예약정보</h3>
<hr>
<b>입력한 생년월일:</b><%=birthday %>
<b>선택한 티겟:</b><%=type %>
<br>
나이:<%=age %>세<br> 
등급:<%=grade %><br> 
할인 적용 금액:<%=price %>원<br> 
지불금액:<%=type-price %>원<br> 
</body>
</html>