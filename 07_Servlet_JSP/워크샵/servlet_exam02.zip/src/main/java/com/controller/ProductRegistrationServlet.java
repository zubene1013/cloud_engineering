package com.controller;

import java.io.IOException;
import java.util.HashMap;
import com.dto.Product;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/productReg")
public class ProductRegistrationServlet extends HttpServlet {

	private HashMap<String, Product> products = new HashMap<String, Product>();

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
	
			String name=request.getParameter("name");
			String id=request.getParameter("id");
			int amount=Integer.parseInt(request.getParameter("amount"));
			
			Product temp=products.get(id);
			if(temp==null){
				temp=new Product(name, id, amount);
				products.put(id, temp);
			}else{
				temp.setAmount(temp.getAmount()+amount);
			}
			
			request.setAttribute("products", products);
			
			RequestDispatcher dis = request.getRequestDispatcher("productInfo.jsp");
			dis.forward(request, response);
			
	}

}
