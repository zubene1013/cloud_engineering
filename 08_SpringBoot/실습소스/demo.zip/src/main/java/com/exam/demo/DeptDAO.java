package com.exam.demo;

import org.springframework.stereotype.Component;

@Component
public class DeptDAO {

    public DeptDAO(){
        System.out.println("DeptDAO");
    }
}
