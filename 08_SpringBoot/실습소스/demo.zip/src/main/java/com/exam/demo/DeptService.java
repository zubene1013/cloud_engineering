package com.exam.demo;

import org.springframework.stereotype.Component;

@Component
public class DeptService {

    public DeptService(){
        System.out.println("DeptService");
    }

}
