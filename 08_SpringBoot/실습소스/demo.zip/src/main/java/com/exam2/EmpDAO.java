package com.exam2;

import org.springframework.stereotype.Component;

@Component
public class EmpDAO {

    public EmpDAO(){
        System.out.println("EmpDAO");
    }
}
