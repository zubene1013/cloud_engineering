package com.exam.controller;

import com.exam.api.ApiResponse;
import com.exam.dto.TodoDTO;
import com.exam.exception.DuplicatedIdException;
import com.exam.exception.RecordNotFoundException;
import com.exam.service.TodoMyBatisService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController  // @Controller + @ResponseBody
public class TodoController {

    TodoMyBatisService service;
    public TodoController(TodoMyBatisService service) {
        this.service = service;
    }

    @GetMapping("/welcome")
    public String welcome(){
        return "welcome";
    }


    //1. todo 목록보기 ( select )
    @GetMapping("/todos")
    public ResponseEntity<ApiResponse<List<TodoDTO>>> getAllTodos(){
        ApiResponse<List<TodoDTO>> result = ApiResponse.ok("Todo 목록조회 성공", service.findAll());
        return ResponseEntity.ok(result);
//        return ResponseEntity.noContent().build();
    }


   //2. 특정 todo 보기 ( select )
    @GetMapping("/todos/{xxx}")
    public ResponseEntity<ApiResponse<TodoDTO>> todoById(@PathVariable int xxx){
        TodoDTO dto = service.findById(xxx);
        if(dto == null){
//                return ResponseEntity.notFound().build();
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.fail(xxx+ " 특정 id 조회 실패", dto));
             throw new RecordNotFoundException(xxx+ " 특정 id 조회 실패");
        }else{
              return  ResponseEntity.ok(ApiResponse.ok(xxx + " 특정 id 조회 성공", dto));
        }
    }



    //3. todo 저장
    @PostMapping("/todos")
    public ResponseEntity<ApiResponse<TodoDTO>> addTodo(@RequestBody TodoDTO todoDTO){

        /*
             중복저장 예외처리
             1. 전달된 id값이 있는지 확인
             2. 없으면 저장
                있으면 예외 발생: DupulicatedIdException.java
             3. 사용자 개선된 응답 처리함.
         */

        TodoDTO resultDTO = service.findById(todoDTO.getId());
        if( resultDTO != null){
            throw new DuplicatedIdException(todoDTO.getId() +" 가 존재합니다.");
        }else{
            int n = service.save(todoDTO);
            ApiResponse<TodoDTO> result = ApiResponse.ok("저장 성공", todoDTO);

            // 역할: 현재 새로 생성된 Todo를 볼수 있는 링크 자동 생생.
            URI location =  ServletUriComponentsBuilder
                    .fromCurrentRequest()
                    .path("/{id}")
                    .buildAndExpand(todoDTO.getId()) // 위 {id}에 설정
                    .toUri();

            return ResponseEntity.created(location).body(result);
        }

    }

    
    //4. todo 수정 ( 전체수정 )
    @PutMapping("/todos/{id}")
    public ResponseEntity<ApiResponse<TodoDTO>>updateTodo(@PathVariable int id, @RequestBody TodoDTO todoDTO){
        todoDTO.setId(id);
        service.updateById(todoDTO);
        ApiResponse<TodoDTO> result = ApiResponse.ok("수정 성공", todoDTO);
        return ResponseEntity.ok(result);
    }
    //4. todo 삭제
    @DeleteMapping("/todos/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteTodo(@PathVariable int id){
        int n  = service.deleteById(id);
//        return ResponseEntity.ok(ApiResponse.ok("삭제 성공",null));
        return ResponseEntity.noContent()
                .header("X-request-result","delete")
                .build();
    }
}
