package com.exam.exception;

import com.exam.api.ApiResponse;
import com.exam.dto.TodoDTO;
import com.exam.service.TodoMyBatisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestGlobalExceptionHandler {

    //필요한 빈 주입 가능.
    @Autowired
    TodoMyBatisService service;

    @ExceptionHandler(RecordNotFoundException.class)
    public ResponseEntity<ApiResponse<TodoDTO>> handleException(Exception e) {
        System.out.println("RestGlobalExceptionHandler>>>>>>>>>>>>>>>>>");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(ApiResponse.fail(e.getMessage(), null));
    }
    @ExceptionHandler(DuplicatedIdException.class)
    public ResponseEntity<ApiResponse<TodoDTO>> handleException2(Exception e) {
        System.out.println("RestGlobalExceptionHandler>>>>>>>>>>>>>>>>>");
        return ResponseEntity.status(HttpStatus.CONFLICT).
                body(ApiResponse.fail(e.getMessage(), null));
    }
}
