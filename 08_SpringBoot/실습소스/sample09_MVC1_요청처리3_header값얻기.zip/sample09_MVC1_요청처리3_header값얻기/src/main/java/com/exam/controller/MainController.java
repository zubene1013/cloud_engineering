package com.exam.controller;


import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Enumeration;


@Controller
public class MainController {

    @GetMapping("/main")
    public String  main(HttpServletRequest request){

        Enumeration<String> enu = request.getHeaderNames();
        while (enu.hasMoreElements()){
            String key = enu.nextElement();
            String value = request.getHeader(key);
            System.out.println(key+":"+value);
        }

        //헤더값을 알고있는경우
        String browser = request.getHeader("user-agent");
        System.out.println("user-agent: " +browser);


        return "main";
    }


}
