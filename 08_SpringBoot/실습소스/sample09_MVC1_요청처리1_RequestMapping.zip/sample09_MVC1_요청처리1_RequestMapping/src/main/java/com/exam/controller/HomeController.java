package com.exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

    // http://localhost:8080/hello
    @RequestMapping("/hello")
    public String hello(){
        //Model과 View처리
        System.out.println("hello");
        return "main";
    }
}
