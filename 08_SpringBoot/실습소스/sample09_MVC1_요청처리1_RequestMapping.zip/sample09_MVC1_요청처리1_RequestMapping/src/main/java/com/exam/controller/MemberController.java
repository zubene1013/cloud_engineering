package com.exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {

    // 화면 보여주는 요청
    // http://localhost:8080/memberForm
    @RequestMapping(value = "/memberForm")
    public String hello(){
        System.out.println("memberForm");
        return "memberForm";
    }




}
