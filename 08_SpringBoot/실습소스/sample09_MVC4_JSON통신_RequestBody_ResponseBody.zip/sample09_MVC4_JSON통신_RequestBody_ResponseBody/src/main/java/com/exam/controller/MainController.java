package com.exam.controller;


import com.exam.dto.LoginDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;


@Controller
public class MainController {

    //1. 리턴타입이 String
    @GetMapping("/aaa")
    @ResponseBody // 리턴되는 값 자체로 응답처리됨
    public String  aaa(){
        return "Hello World";
    }

    //2.
    @GetMapping("/bbb")
    @ResponseBody // LoginDTO를 JSON포맷으로 바꿔줌
    public LoginDTO  bbb(){
        LoginDTO dto = new LoginDTO("inky","1234");
        return dto;
    }

    //3.
    @GetMapping("/ccc")
    @ResponseBody // ArrayList JSON포맷으로 바꿔줌
    public ArrayList<LoginDTO>  ccc(){

        ArrayList<LoginDTO> list = new ArrayList<>();
        list.add(new LoginDTO("inky","1234"));
        list.add(new LoginDTO("inky2","1234"));

        return list;
    }

    @GetMapping("/ddd")
    @ResponseBody // HashMap JSON포맷으로 바꿔줌
    public HashMap<String ,ArrayList<LoginDTO>>  ddd(){

        ArrayList<LoginDTO> list = new ArrayList<>();
        list.add(new LoginDTO("inky","1234"));
        list.add(new LoginDTO("inky2","1234"));

        HashMap<String ,ArrayList<LoginDTO>> map = new HashMap<>();
        map.put("one", list);
        return map;
    }

    //1. 리턴타입이 String
    @GetMapping(value = "/eee", produces = "text/xml")
    @ResponseBody // 리턴되는 값 자체로 응답처리됨
    public String  eee(){
        return "<Person><name>hong</name><age>20</age></Person>";
    }
    //1. 리턴타입이 String
    @GetMapping(value = "/fff", produces = "text/html")
    @ResponseBody // 리턴되는 값 자체로 응답처리됨
    public String  fff(){
        return "<html><body><h1>Hello</h1></body></html>";
    }
    /// ////////////////////////////////////////////
    //
    /*
        POST  http://localhost:8080/ggg

         {
           "userid":"xxx",
           "password":"1234"
         }

     */
    @PostMapping("/ggg")
    @ResponseBody // 리턴되는 값 자체로 응답처리됨
    public String  ggg( @RequestBody LoginDTO dto){
        System.out.println(dto);
        return "Hello World";
    }

    /// ////////////////////////////////////////////
    //
    /*
        POST  http://localhost:8080/hhh

        [
         {
           "userid":"xxx",
           "password":"1234"
         },
         {
           "userid":"xxx2",
           "password":"1234"
         }
         ]

     */
    @PostMapping("/hhh")
    @ResponseBody // 리턴되는 값 자체로 응답처리됨
    public String  hhh(@RequestBody List<LoginDTO> dto){
        System.out.println(dto);
        return "Hello World";
    }
}
