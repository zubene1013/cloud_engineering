package com.exam.service;

import com.exam.dto.TodoDTO;

import java.util.List;

public interface TodoMyBatisService {
    List<TodoDTO> findAll();
}
