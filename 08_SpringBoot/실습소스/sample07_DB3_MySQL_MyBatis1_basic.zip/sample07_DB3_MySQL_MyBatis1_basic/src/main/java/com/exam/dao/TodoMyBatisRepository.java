package com.exam.dao;

import com.exam.dto.TodoDTO;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TodoMyBatisRepository {

    SqlSessionTemplate sqlSessionTemplate;
    public TodoMyBatisRepository(SqlSessionTemplate sqlSessionTemplate) {
        this.sqlSessionTemplate = sqlSessionTemplate;
    }

    //목록보기
    public List<TodoDTO> findAll(){
        return sqlSessionTemplate.selectList("com.exam.config.TodoMapper.findAll");
    }


}
