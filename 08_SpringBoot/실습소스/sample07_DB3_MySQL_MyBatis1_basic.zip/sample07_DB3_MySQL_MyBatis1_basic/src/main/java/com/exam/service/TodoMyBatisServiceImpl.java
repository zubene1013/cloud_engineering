package com.exam.service;

import com.exam.dao.TodoMyBatisRepository;
import com.exam.dto.TodoDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("todoMyBatisService") // "todoMyBatisService" 필요없음.
public class TodoMyBatisServiceImpl implements TodoMyBatisService {

    TodoMyBatisRepository todoMyBatisRepository;
    public TodoMyBatisServiceImpl(TodoMyBatisRepository todoMyBatisRepository) {
        this.todoMyBatisRepository = todoMyBatisRepository;
    }

    @Override
    public List<TodoDTO> findAll() {
        return todoMyBatisRepository.findAll();
    }
}
