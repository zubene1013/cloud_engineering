package com.exam.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;


@Controller
public class MainController {

    @GetMapping("/main")
    public String  main(){
        System.out.println("main");
        
        //예외발생
        if(true) throw new IllegalArgumentException("IllegalArgumentException 예외발생");

        return "main";
    }

    @GetMapping("/main2")
    public String  main2(){
        System.out.println("main2");

        //예외발생
        if(true) throw new NullPointerException("NullPointerException 예외발생");

        return "main";
    }

    //로컬
    //특정 Controller내에서 처리
    //2가지 기능: View+Model
    // @ExceptionHandler
    // @ExceptionHandler(value=IllegalArgumentException.class)
//    @ExceptionHandler(value={IllegalArgumentException.class, NullPointerException.class})
//    //public ModelAndView handleException(Exception ex, RedirectAttributes redirectAttributes){}
//    public String handleException(Exception ex, Model model){
//
//        model.addAttribute("message", ex.getMessage());
//        return "error/error";  // error/error.html
//    }




}
