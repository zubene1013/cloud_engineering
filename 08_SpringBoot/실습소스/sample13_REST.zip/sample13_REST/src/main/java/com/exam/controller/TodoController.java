package com.exam.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController  // @Controller + @ResponseBody
public class TodoController {

    @GetMapping("/welcome")
    public String welcome(){
        return "welcome";
    }
}
