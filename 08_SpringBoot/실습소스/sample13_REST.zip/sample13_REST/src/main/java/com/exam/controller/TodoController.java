package com.exam.controller;

import com.exam.dto.TodoDTO;
import com.exam.service.TodoMyBatisService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController  // @Controller + @ResponseBody
public class TodoController {

    TodoMyBatisService service;
    public TodoController(TodoMyBatisService service) {
        this.service = service;
    }

    @GetMapping("/welcome")
    public String welcome(){
        return "welcome";
    }
    //1. todo 목록보기 ( select )
    @GetMapping("/todos")
    public List<TodoDTO> todos(){
        return service.findAll();
    }
    //2. 특정 todo 보기 ( select )
    // GET http://localhost:8080/todos/1
    // GET http://localhost:8080/todos/2
    @GetMapping("/todos/{xxx}")
//    public TodoDTO  todoById(@PathVariable("xxx") int xxx){
    public TodoDTO  todoById(@PathVariable int xxx){
        return service.findById(xxx);
    }
    //3. todo 저장
    // 권장: 새롭게 생성된 데이터를 반환함.
    //     이유는 SOAP에서는 생성된 데이터를 화면으로 볼 수 있음.
    //    하지만 REST에서는 화면이 없기 때문에 새롭게 생성된 데이터를 반환하여
    //    클라이언트에게 정보를 제공함.
    /*
        요청 방법
        POST  http://localhost:8080/todos

       {
        "id": 4,
        "name": "유관순",
        "job": "Learn JPA"
        }

     */
    @PostMapping("/todos")
    public TodoDTO createTodo(@RequestBody TodoDTO todoDTO){
         int n = service.save(todoDTO);
         return todoDTO;
    }

    //4. todo 수정 ( 전체수정 )
    /*
          누구를 수정할건지?  id=4
        http://localhost:8080/todos/4

          뭘 수정할건지? name과 job
          {
             "name":"유관순2",
             "job":"Learn JPA2"
          }
     */


    @PutMapping("/todos/{id}")
    public TodoDTO updateTodo( @PathVariable int id,
                            @RequestBody TodoDTO todoDTO){

        todoDTO.setId(id);
        service.updateById(todoDTO);
        return todoDTO;
    }
    //4. todo 삭제
    // delete  http://locahost:8080/todos/4
    @DeleteMapping("/todos/{id}")
    public void deleteTodo(@PathVariable int id){
        int n  = service.deleteById(id);
    }

}
