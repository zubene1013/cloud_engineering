package com.exam.controller;


import com.exam.dto.LoginDTO;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;


@Controller
// 세션에 저장하고자하는 key 설정
@SessionAttributes(names = {"bbb","ccc"})
public class MainController2 {
    // application scope에 저장
    @Autowired
    ServletContext x;
    @GetMapping("/k")
    public String  main(Model model){

        // request scope에 저장
        model.addAttribute("aaa","hong1");

        // session scope에 저장
        model.addAttribute("bbb","hong2");
        model.addAttribute("ccc","hong3");

        // application scope에 저장
        x.setAttribute("ddd","hong4");

        return "target"; // target.html
    }
    @GetMapping("/k2")
    public String  main2(){

        return "target"; // target.html
    }





}
