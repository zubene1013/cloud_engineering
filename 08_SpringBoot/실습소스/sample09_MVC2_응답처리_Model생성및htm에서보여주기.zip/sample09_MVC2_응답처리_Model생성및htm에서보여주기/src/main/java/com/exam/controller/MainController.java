package com.exam.controller;


import com.exam.dto.LoginDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;


@Controller
public class MainController {

    @GetMapping("/m")
    public String  main(HttpServletRequest request){

        request.setAttribute("userid","inky4832");
        request.setAttribute("email","inky4832@exam.com");

        return "main";
    }
    @GetMapping("/m2")
    public String  main2(Model model){

        model.addAttribute("userid","inky4832");
        model.addAttribute("email","inky4832@exam.com");

        return "main2";
    }
    @GetMapping("/m3")
    public String  main3(Map<String,String> map){

        map.put("userid","inky4832");
        map.put("email","inky4832@exam.com");

        return "main3";
    }

    @GetMapping("/m4")
    public String  main4( @ModelAttribute("xxx") LoginDTO dto){ // 모델이 됨. 즉 html에서 보여줄 수 있음.
                                        // 자동으로 ("loginDTO", dto)
                                        // 명시적으로 key 지정 가능. @ModelAttribute("key")
                                        // 이제는 ("key", dto);
        dto.setUserid("inky4832");
        dto.setPassword("1234");
        return "main4";
    }
    @GetMapping("/m5")
    public String  main5(  @ModelAttribute("yyy") 
                               ArrayList<String> nameList){ // 자동으로 모델로 저장됨.
                                                           // @ModelAttribute("yyy") 지정했기 때문에
                                                            //  ("yyy", nameList

         nameList.add("inky4832");
         nameList.add("lee3842");
         nameList.add("park424");

        return "main5";
    }
    @GetMapping("/m6")
    public  ModelAndView main6( ){

        //ModelAndView
        ModelAndView mv = new ModelAndView();

        mv.setViewName("main6"); // view 지정  main6.html

        // 다음코드는 모델 설정
        mv.addObject("userid","inky4832");
        mv.addObject("dto",new LoginDTO("inky4932","123456"));
        mv.addObject("list", Arrays.asList("Lee","park","Kim"));
        mv.addObject("dtolist", Arrays.asList(new LoginDTO("xxxxxx","123456"),
                new LoginDTO("yyyyyy","123456"),
                new LoginDTO("zzzzz","123456")
                                                            ));

        return mv;
    }

}
