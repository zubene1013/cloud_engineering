package com.exam.controller.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InterceptorWebConfig 
        implements WebMvcConfigurer {
    
    //Interceptor를 등록하는 메서드가 제공됨
     @Autowired
     MyInterceptor myInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
//        registry.addInterceptor(new MyInterceptor())
        registry.addInterceptor(myInterceptor).addPathPatterns("/main","/aaa/*","/bbb*");
    }
}
