package com.exam.controller;

import com.exam.api.ApiResponse;
import com.exam.dto.TodoDTO;
import com.exam.service.TodoMyBatisService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController  // @Controller + @ResponseBody
public class TodoController {

    TodoMyBatisService service;
    public TodoController(TodoMyBatisService service) {
        this.service = service;
    }

    @GetMapping("/welcome")
    public String welcome(){
        return "welcome";
    }


    //1. todo 목록보기 ( select )
    @GetMapping("/todos")
    public ApiResponse<List<TodoDTO>> todos(){
        return ApiResponse.ok("Todo 목록조회 성공", service.findAll());
    }
   //2. 특정 todo 보기 ( select )
@GetMapping("/todos/{xxx}")
public ApiResponse<TodoDTO> todoById(@PathVariable int xxx){
    TodoDTO dto = service.findById(xxx);
    if(dto != null){
        return ApiResponse.ok(xxx + " 특정 id 조회 성공", dto);
    }else{
        return ApiResponse.fail(xxx+ " 특정 id 조회 실패", dto);
    }
}

    //3. todo 저장
    @PostMapping("/todos")
    public ApiResponse<TodoDTO> createTodo(@RequestBody TodoDTO todoDTO){
        int n = service.save(todoDTO);
        return ApiResponse.ok("저장 성공", todoDTO);
    }

    //4. todo 수정 ( 전체수정 )
@PutMapping("/todos/{id}")
public ApiResponse<TodoDTO> updateTodo(@PathVariable int id, @RequestBody TodoDTO todoDTO){
    todoDTO.setId(id);
    service.updateById(todoDTO);
    return ApiResponse.ok("수정 성공", todoDTO);
}

    //4. todo 삭제
    // delete  http://locahost:8080/todos/4
    @DeleteMapping("/todos/{id}")
    public ApiResponse<Void> deleteTodo(@PathVariable int id){
        int n  = service.deleteById(id);
        return ApiResponse.ok("삭제 성공",null);
    }
}
