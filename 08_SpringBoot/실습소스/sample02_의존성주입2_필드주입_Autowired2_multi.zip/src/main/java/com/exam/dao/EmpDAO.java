package com.exam.dao;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Repository("EmpRepository")
public class EmpDAO {
    public EmpDAO() {
        System.out.println("EmpDAO");
    }

    //DB연동 가정
    public List<String> findAll(){
//        return Arrays.asList("Hong","Lee"); //수정불가
        return new ArrayList<>(Arrays.asList("Hong","Lee")); //수정가능
    }
}
