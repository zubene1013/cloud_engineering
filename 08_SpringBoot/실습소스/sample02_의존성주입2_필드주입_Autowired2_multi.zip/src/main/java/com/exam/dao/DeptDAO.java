package com.exam.dao;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Repository("DeptRepository")
public class DeptDAO {
    public DeptDAO() {
        System.out.println("DeptDAO");
    }

    //DB연동 가정
    public List<String> findAll(){
//        return Arrays.asList("홍길동","이순신"); //수정불가
        return new ArrayList<>(Arrays.asList("홍길동","이순신")); //수정불가
    }
}
