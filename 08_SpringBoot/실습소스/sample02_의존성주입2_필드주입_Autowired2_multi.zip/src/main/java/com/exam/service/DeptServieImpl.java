package com.exam.service;

import com.exam.dao.DeptDAO;
import com.exam.dao.EmpDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service("service")
public class DeptServieImpl {

    @Autowired
    DeptDAO dao;

    @Autowired
    EmpDAO  empdao;
    

    public List<String> findAll(){
        List<String> list = dao.findAll();
        List<String> empList = empdao.findAll();
        list.addAll(empList);
        return list;
    }
    
}
