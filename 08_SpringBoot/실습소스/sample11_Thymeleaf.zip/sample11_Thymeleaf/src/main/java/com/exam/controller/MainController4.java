package com.exam.controller;

import com.exam.dto.LoginDTO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class MainController4 {


    //4. 경로(링크)
    @GetMapping("/m5")
    public String  m(Model model){

        model.addAttribute("login", new LoginDTO("inky4832","1234"));
        model.addAttribute("login2", new LoginDTO(null,"1234"));

        List<LoginDTO> list = Arrays.asList(new LoginDTO("inky4832","1234"),
                                         new LoginDTO("kim4832","1234"),
                                      new LoginDTO("park4832","1234")
                                            );

        model.addAttribute("myList",list);

        return "main3";
    }

   

}
