package com.exam.controller;

import com.exam.dto.LoginDTO;
import org.apache.juli.logging.Log;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class MainController3 {


    //3. scope에 객체 저장하고 html에 보여주기 ( 제어문 처리: if, swtich, 3항연산자, 반복문 )
    @GetMapping("/m3")
    public String  m(Model model){

        model.addAttribute("login", new LoginDTO("inky4832","1234"));
        model.addAttribute("login2", new LoginDTO(null,"1234"));

        List<LoginDTO> list = Arrays.asList(new LoginDTO("inky4832","1234"),
                                         new LoginDTO("kim4832","1234"),
                                      new LoginDTO("park4832","1234")
                                            );

        model.addAttribute("myList",list);

        return "main3";
    }

   

}
