package com.exam.service;

import org.springframework.stereotype.Service;

@Service("service")
public class DeptServieImpl {

    public DeptServieImpl() {
        System.out.println("DeptServieImpl");
    }
}
