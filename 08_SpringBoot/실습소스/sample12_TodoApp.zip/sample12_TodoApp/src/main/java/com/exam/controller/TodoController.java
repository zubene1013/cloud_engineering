package com.exam.controller;

import com.exam.dto.TodoDTO;
import com.exam.mapper.TodoMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import java.util.List;

@Controller
@SessionAttributes(value = {"my_login"})
public class TodoController {

    TodoMapper todoMapper;
    public TodoController(TodoMapper todoMapper) {
        this.todoMapper = todoMapper;
    }

    @GetMapping("/todo-list")
    public String  todoList(Model model) {
      // 로그인 계정 얻기
        String userid = (String)model.getAttribute("my_login");

        List<TodoDTO> todoList = todoMapper.findAll(userid);;

        //모델에 저장
        model.addAttribute("todoListFindAll",todoList);

        return "todoList"; // todoList.html
    }

}
