package com.exam.config;

import com.exam.dto.TodoDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TodoMapper {
  List<TodoDTO> findAll();
}
