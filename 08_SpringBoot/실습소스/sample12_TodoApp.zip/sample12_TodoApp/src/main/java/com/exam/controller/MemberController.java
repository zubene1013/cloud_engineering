package com.exam.controller;

import com.exam.dto.MemberDTO;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MemberController {


    @GetMapping("/signup")
    public String  signupForm(Model model){

        model.addAttribute("xxx", new MemberDTO());
        return "memberForm";
    }
    @PostMapping("/signup")
    public String  signup(@Valid @ModelAttribute("xxx") MemberDTO memberDTO,
                          BindingResult bindingResult){
        //검증실패
        if(bindingResult.hasErrors()){
            return "memberForm";
        }
        //검증성공
        return "redirect:home";  //PRG 패턴
    }

}
