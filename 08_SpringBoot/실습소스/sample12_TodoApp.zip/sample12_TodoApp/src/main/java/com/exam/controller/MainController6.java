package com.exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.util.Arrays;

@Controller
public class MainController6 {


    // 6. 화면재사용
    @GetMapping("/m6")
    public String  m(Model model){


        return "main6";
    }

}
