package com.exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController4 {


    //4. 경로(링크)
    @GetMapping("/m4")
    public String  m(Model model){
        model.addAttribute("userid","kim");
        return "main4";
    }

    @GetMapping("/m4-1")
    public String  m1(@RequestParam(value = "id", required = false) String userid,
                      @RequestParam(value = "pw", required = false) String passwd
                       ){
        System.out.println("userid:"+userid+"  passwd:"+passwd);
        return "loginForm";
    }
    @GetMapping(value = "/m4-2")
    public String  m2(@RequestParam(value = "userid", required = false) String userid,
                      @RequestParam(value = "password", required = false) String passwd
    ){
        System.out.println("userid:"+userid+"  passwd:"+passwd);
        return "loginForm";
    }
}
