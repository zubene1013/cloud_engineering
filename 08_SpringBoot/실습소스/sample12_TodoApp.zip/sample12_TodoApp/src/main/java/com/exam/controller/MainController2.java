package com.exam.controller;

import com.exam.dto.TodoDTO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController2 {


    //2. scope에 개체 저장하고 html에 보여주기
    @GetMapping("/m2")
    public String  m(Model model){

        model.addAttribute("login", new TodoDTO("inky4832","1234"));

        return "main2";
    }

   

}
