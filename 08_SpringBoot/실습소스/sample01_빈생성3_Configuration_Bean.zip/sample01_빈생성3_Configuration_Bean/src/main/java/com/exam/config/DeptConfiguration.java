package com.exam.config;

// DeptController, DeptServiceImpl, DeptDAO를 명시적으로 생성

import com.exam.controller.DeptController;
import com.exam.dao.DeptDAO;
import com.exam.service.DeptServieImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DeptConfiguration {

    @Bean
    public DeptController createDeptController() {
        return new DeptController();
    }
    @Bean
    public DeptServieImpl createDeptServieImpl() {
        return new DeptServieImpl();
    }
    @Bean
    public DeptDAO createDeptDAO() {
        return new DeptDAO();
    }
}
