package com.exam.service;

import org.springframework.stereotype.Service;


public class DeptServieImpl {

    public DeptServieImpl() {
        System.out.println("DeptServieImpl");
    }
}
