package com.exam.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;


@Controller
public class MainController {

    @GetMapping("/main")
    public String  aaa(){
        System.out.println("main");
        return "main";
    }

    @GetMapping("/forward")
    public String  forward(Model model){
        System.out.println("forward");
        model.addAttribute("userid","inky");
        return "forward:main";
    }

    @GetMapping("/redirect")
    public String  redirect(Model model){
        System.out.println("redirect");
        model.addAttribute("userid","inky");
        return "redirect:main";
    }

    //flash scope
    @GetMapping("/flash")
    public String  flash(RedirectAttributes model){
        System.out.println("flash");

        model.addFlashAttribute("userid","inky");

        return "redirect:main";
    }

}
