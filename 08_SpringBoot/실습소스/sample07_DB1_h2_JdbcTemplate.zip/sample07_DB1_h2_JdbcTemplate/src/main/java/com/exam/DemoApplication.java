package com.exam;

import com.exam.dto.TodoDTO;
import com.exam.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
        System.out.println("Hello World 안녕하세요");
	}

    @Autowired
    TodoService todoService;

    @Override
    public void run(String... args) throws Exception {

        List<TodoDTO> list = todoService.findAll();;
        System.out.println(list);
        System.out.println("-------------------------");
        TodoDTO dto = todoService.findById(1);
        System.out.println(dto);
    }
}
